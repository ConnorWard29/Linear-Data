﻿using System;
using System.Collections;
public class Program {
   public static void Main(string[] args) {
         Stack st = new Stack();
         Stack rev = new Stack();
         int n, i;
         Console.WriteLine("Enter the desired number of intergers: ");
         n = Convert.ToInt32(Console.ReadLine());
         Console.Write("Input {0} elements in the list in order from last to first:\n", n);
         for (i = 0; i < n; i++)
         {
            Console.Write("element - {0} : ", i);
            st.Push(Convert.ToInt32(Console.ReadLine()));
         }
         Console.WriteLine("Current stack: ");
         foreach(int c in st) {
            Console.Write(c + " ");
         }
         Console.WriteLine();
         while (st.Count != 0) {
            rev.Push(st.Pop());
         }
         Console.WriteLine("Reversed stack: ");
         foreach(int c in rev) {
            Console.Write(c + " ");
         }
    }
}