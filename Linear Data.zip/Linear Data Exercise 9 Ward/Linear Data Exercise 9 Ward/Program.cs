﻿using System;
using System.Collections.Generic;

public class Exercise9
{
    static void Main()
    {
        int n;
        Console.Write("Input the value for N:" );
        n = Convert.ToInt32(Console.ReadLine());
        Queue<int> queue = new Queue<int>();
        queue.Enqueue(n);
        int index = 0;
        Console.WriteLine("N: " +n);
        while (queue.Count < 50)
        {
            index++;
            int current = queue.Dequeue();
            Console.WriteLine(" " + current);
           
            queue.Enqueue(current + 1);
            queue.Enqueue(2 * current + 1);
            queue.Enqueue(current + 2);
        }
    }
}
